<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Ladder" tilewidth="16" tileheight="16" tilecount="4" columns="2">
 <image source="LadderNew.png" width="32" height="32"/>
</tileset>
