package io.github.eng1group9.systems;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.utils.viewport.Viewport;


/**
 * Handles the textbox (as of 02/12 only used in Bob event)
 */
public class TextInputSystem {
    public Stage st;
    private Skin sk;
    private TextField textInp;



    public TextInputSystem(Viewport view) {
        st = new Stage(view);
        Gdx.input.setInputProcessor(st);
        sk = new Skin(Gdx.files.internal("skins/uiskin/uiskin.json")); //Default UI skin for libGDX

        textInp = new TextField("", sk);
        textInp.setMessageText("");
        textInp.setSize(150, 20);
        textInp.setPosition(400,600);

        st.addActor(textInp);
    }


    /**
     * Textbox is drawn on the screen and keyboard input is automatically targeted on the textbox.
     *
     * @param delta - handles timing.
     */
    public void renderTB(float delta) {
        st.act(delta);
        st.draw();
        st.setKeyboardFocus(textInp);
    }


    /**
     *
     * @return the text in the textbox (used for comparison)
     */
    public String getText() {
        return textInp.getText();
    }


    /**
     * Clears the textbox (had to add this to deal with text box having keyboard input
     * when the player was to interact and then leave before interacting with it again
     * e.g. when they interact with it and leave then move and interact again is would have
     * movement keyboard input like adddwwwsda in it.
     */
    public void clear() {
        textInp.setText("");
    }





}
