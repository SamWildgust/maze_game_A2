package io.github.eng1group9.systems;

import io.github.eng1group9.Main;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;

import static org.junit.Assert.*;

/**
 * tests for the Bob secret event
 */
public class BobEventTest {

    /**
     * sets up a suitable tiled map for the tests
     * @throws Exception
     */
    @Before
    public void setup() throws Exception {

        Class.forName("io.github.eng1group9.Main");

        //set up a tiled map for the tests
        com.badlogic.gdx.maps.tiled.TiledMap testMap = new com.badlogic.gdx.maps.tiled.TiledMap();

        //create a bob layer for the map
        com.badlogic.gdx.maps.MapLayer bobLayer = new com.badlogic.gdx.maps.MapLayer();
        bobLayer.setName("BobLayer");
        testMap.getLayers().add(bobLayer);

        Field mapField = io.github.eng1group9.systems.RenderingSystem.class.getDeclaredField("map");
        mapField.setAccessible(true);
        mapField.set(null, testMap);
    }

    /**
     * reset flags afterwards
     */
    @After
    public void tearDown() {
        Main.bobFound = false;
        Main.bobBonus = 0;
        Main.piInteracted = false;
    }

    /**
     * test secretBob only sets bool bobFound if bool piInteracted is true
     */
    @Test
    public void secretBob_requiresPiInteract() {

        //set init. flags
        Main.bobFound = false;
        Main.bobBonus = 0;
        Main.piInteracted = false;

        //try with out the pi
        Main.secretBob();
        assertFalse("Bob should not be found without pi interaction", Main.bobFound);

        //try interaction with flag as true
        Main.piInteracted = true;
        Main.secretBob();
        assertTrue("Bob should be found after pi interaction and secretBob() call", Main.bobFound);
        assertEquals("Bob bonus should be set to 200 when Bob is found", 200, Main.bobBonus);
    }
}
