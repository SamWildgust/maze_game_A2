package io.github.eng1group9.systems;

import io.github.eng1group9.Main;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;

import static org.junit.Assert.*;

/**
 * tests lever event to drop spikes
 */
public class LeverTest {

    @Before
    public void setup() throws Exception {
        Class.forName("io.github.eng1group9.Main");

        //set up a tiled map for the tests
        com.badlogic.gdx.maps.tiled.TiledMap testMap = new com.badlogic.gdx.maps.tiled.TiledMap();
        
        //create spikes layer
        com.badlogic.gdx.maps.MapLayer spikesLayer = new com.badlogic.gdx.maps.MapLayer();
        spikesLayer.setName("Spikes");
        testMap.getLayers().add(spikesLayer);

        //create lever layer ("switch" in tiled map)
        com.badlogic.gdx.maps.MapLayer switchLayer = new com.badlogic.gdx.maps.MapLayer();
        switchLayer.setName("Switch");
        testMap.getLayers().add(switchLayer);


        //create collision layer with chestRoomSpikes object
        com.badlogic.gdx.maps.MapLayer collisionLayer = new com.badlogic.gdx.maps.MapLayer();
        collisionLayer.setName("Collision");

        com.badlogic.gdx.maps.objects.RectangleMapObject spikesObj = new com.badlogic.gdx.maps.objects.RectangleMapObject(0,0,10,10);
        spikesObj.setName("chestRoomSpikes");

        collisionLayer.getObjects().add(spikesObj);
        testMap.getLayers().add(collisionLayer);

        //rendering system fopr test
        Field mapField = io.github.eng1group9.systems.RenderingSystem.class.getDeclaredField("map");
        mapField.setAccessible(true);
        mapField.set(null, testMap);

        //collision sys.
        Field collisionMapField = io.github.eng1group9.systems.CollisionSystem.class.getDeclaredField("map");
        collisionMapField.setAccessible(true);
        collisionMapField.set(Main.collisionSystem, testMap);

        //make the collision system and add the spikes
        Field wcField = io.github.eng1group9.systems.CollisionSystem.class.getDeclaredField("worldCollision");
        wcField.setAccessible(true);
        java.util.List<com.badlogic.gdx.math.Rectangle> list = new java.util.ArrayList<>();
        list.add(spikesObj.getRectangle());
        wcField.set(Main.collisionSystem, list);
    }

    /**
     * reset flags afterwards
     */
    @After
    public void tearDown() {
        Main.spikesLowered = false;
    }

    /**
     * test dropSpikes function actually lowers the spikes by setting bool to true
     */
    @Test
    public void dropSpikes_setsSpikesLowered() {
        Main.spikesLowered = false;
        Main.dropSpikes();
        assertTrue("dropSpikes should set spikesLowered to true", Main.spikesLowered);
    }
}
