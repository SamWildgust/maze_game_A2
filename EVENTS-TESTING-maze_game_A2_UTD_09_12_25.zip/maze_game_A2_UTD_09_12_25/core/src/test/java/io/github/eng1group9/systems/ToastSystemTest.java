package io.github.eng1group9.systems;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import com.badlogic.gdx.graphics.Color;

import java.util.List;

public class ToastSystemTest {

    private ToastSystem toastSystem;

    /**
     * Clears the contents of the toastSystem used for testing (precondition for testing)
     */
    @Before
    public void init() {
        toastSystem.getToasts().clear();
    }

    /**
     * Tests that the creation of a new toastSystem starting with toasts added immediately works as expected  (default colours, corrct size, etc.).
     * @return void
     */
    @Test
    public void testConstructor() {
        toastSystem.addToast("Bob");
        List<ToastSystem.Toast> toasts = ToastSystem.getToasts();

        assertEquals(1, toasts.size());

        assertEquals("Bob", toasts.get(0).getText());

        assertEquals(new Color(1,1,1,1), toasts.get(0).getColour());
    }


    /**
     * Tests that unexpired toasts aren't removed before they are expired.
     * @return void
     */
    @Test
    public void testUnexpired() {
        toastSystem.addToast("Bob");

        toastSystem.clearExpiredToasts();
        assertEquals(1, toastSystem.getToasts().size());
    }


    /**
     *Tests that expired toasts are removed from the toastSystem (toasts expire after they have been in the system for > than 5 seconds).
     *
     * @throws InterruptedException - Thread.sleep() is not thread safe (but this test shoudln't cause any issues with this).
     */
    @Test
    public void testExpired() throws InterruptedException {
        toastSystem.addToast("Bob");
        Thread.sleep(5001);

        toastSystem.clearExpiredToasts();
        assertEquals(0, toastSystem.getToasts().size());
    }

    @Test
    public void testAddToast() {
        toastSystem.addToast("Bob");

        assertEquals(1, toastSystem.getToasts().size());
    }
}
