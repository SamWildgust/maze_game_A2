package io.github.eng1group9.systems;

import io.github.eng1group9.Main;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * tests for the door events
 */
public class DoorTest {

    /**
     * sets up a suitable tiled map for tests
     * @throws Exception
     */
    @Before
    public void setup() throws Exception {
        Class.forName("io.github.eng1group9.Main");

        //set up a tiled map for the tests
        com.badlogic.gdx.maps.tiled.TiledMap testMap = new com.badlogic.gdx.maps.tiled.TiledMap();

        //init.s of collision objects for t'doors
        com.badlogic.gdx.maps.MapLayer collisionLayer = new com.badlogic.gdx.maps.MapLayer();
        collisionLayer.setName("Collision");

        com.badlogic.gdx.maps.objects.RectangleMapObject chestDoor = new com.badlogic.gdx.maps.objects.RectangleMapObject(0,0,10,10);
        chestDoor.setName("chestRoomDoor");
        collisionLayer.getObjects().add(chestDoor);

        com.badlogic.gdx.maps.objects.RectangleMapObject exitDoor = new com.badlogic.gdx.maps.objects.RectangleMapObject(20,20,10,10);
        exitDoor.setName("exitDoor");
        collisionLayer.getObjects().add(exitDoor);

        //add the collision layer to the tiled map
        testMap.getLayers().add(collisionLayer);


        // Add the layers that will be hidden by openChestRoomDoor/openExit
        com.badlogic.gdx.maps.MapLayer chestDoorLayer = new com.badlogic.gdx.maps.MapLayer();
        chestDoorLayer.setName("ChestDoorClosed");
        testMap.getLayers().add(chestDoorLayer);

        com.badlogic.gdx.maps.MapLayer exitDoorLayer = new com.badlogic.gdx.maps.MapLayer();
        exitDoorLayer.setName("ExitClosed");
        testMap.getLayers().add(exitDoorLayer);

        Field mapField = io.github.eng1group9.systems.RenderingSystem.class.getDeclaredField("map");
        mapField.setAccessible(true);
        mapField.set(null, testMap);

        Field collisionMapField = io.github.eng1group9.systems.CollisionSystem.class.getDeclaredField("map");
        collisionMapField.setAccessible(true);
        collisionMapField.set(Main.collisionSystem, testMap);

        Field wcField = io.github.eng1group9.systems.CollisionSystem.class.getDeclaredField("worldCollision");
        wcField.setAccessible(true);
        java.util.List<com.badlogic.gdx.math.Rectangle> list = new java.util.ArrayList<>();
        list.add(chestDoor.getRectangle());
        list.add(exitDoor.getRectangle());
        wcField.set(Main.collisionSystem, list);


        //make a standin for main.player so we can control hasChestRoomKey/hasExitKey without constructing textures
        io.github.eng1group9.entities.Player mockPlayer = mock(io.github.eng1group9.entities.Player.class);

        //crate flags for test use
        when(mockPlayer.hasChestRoomKey()).thenReturn(false);
        when(mockPlayer.hasExitKey()).thenReturn(false);

        Field playerField = Main.class.getDeclaredField("player");
        playerField.setAccessible(true);
        playerField.set(null, mockPlayer);
    }

    /**
     * reset flags afterwards
     */
    @After
    public void tearDown() {
        Main.chestDoorOpen = false;
        Main.exitOpen = false;
    }


    /**
     * test the chestroomdoor only opens when player has got key
     * @throws Exception
     */
    @Test
    public void openChestRoomDoor_requiresKey() throws Exception {

        //check standin player currently returns false
        io.github.eng1group9.entities.Player p = Main.player;
        

        //try without key
        when(p.hasChestRoomKey()).thenReturn(false);
        Main.chestDoorOpen = false;

        Main.openChestRoomDoor();
        assertFalse("Chest door should not open without key", Main.chestDoorOpen);

        //now we have key open the door
        when(p.hasChestRoomKey()).thenReturn(true);
        Main.openChestRoomDoor();
        assertTrue("Chest door should open when player has key", Main.chestDoorOpen);
    }

    /**
     * test exit door only opens when player has got key
     * @throws Exception
     */
    @Test
    public void openExit_requiresKey() throws Exception {
        
        //check standin player currently returns false like in prev. test
        io.github.eng1group9.entities.Player p = Main.player;

        //try without key
        when(p.hasExitKey()).thenReturn(false);
        Main.exitOpen = false;
        Main.openExit();
        assertFalse("Exit should not open without key", Main.exitOpen);

        //now we have key open the door
        when(p.hasExitKey()).thenReturn(true);
        Main.openExit();
        assertTrue("Exit should open when player has key", Main.exitOpen);
    }
}
