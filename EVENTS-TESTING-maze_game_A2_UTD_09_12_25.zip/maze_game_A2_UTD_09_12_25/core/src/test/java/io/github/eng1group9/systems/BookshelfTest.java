package io.github.eng1group9.systems;

import io.github.eng1group9.Main;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;

import static org.junit.Assert.*;

/**
 * unittests for bookshelf event
 */
public class BookshelfTest {

    /**
     * sets up a suitable tiled map for the tests to use.
     * allows for removal of collision objects by name.
     * @throws Exception
     */
    @Before
    public void setup() throws Exception {

        Class.forName("io.github.eng1group9.Main");

        //init the tiled map for tests
        com.badlogic.gdx.maps.tiled.TiledMap testMap = new com.badlogic.gdx.maps.tiled.TiledMap();

        //craete the layers to compare after the event
        //book
        com.badlogic.gdx.maps.MapLayer bookLayer = new com.badlogic.gdx.maps.MapLayer();
        bookLayer.setName("Book");
        testMap.getLayers().add(bookLayer);

        //bookshelf layer
        com.badlogic.gdx.maps.MapLayer bookShelfLayer = new com.badlogic.gdx.maps.MapLayer();
        bookShelfLayer.setName("BookShelf");
        testMap.getLayers().add(bookShelfLayer);

        //bookshelf moved layer
        com.badlogic.gdx.maps.MapLayer bookShelfMoved = new com.badlogic.gdx.maps.MapLayer();
        bookShelfMoved.setName("BookShelfMoved");
        testMap.getLayers().add(bookShelfMoved);



        //collision objects that placeBook test will remove
        com.badlogic.gdx.maps.MapLayer collisionLayer = new com.badlogic.gdx.maps.MapLayer();
        collisionLayer.setName("Collision");

        com.badlogic.gdx.maps.objects.RectangleMapObject tempWall = new com.badlogic.gdx.maps.objects.RectangleMapObject(0,0,10,10);
        tempWall.setName("tempWall");
        collisionLayer.getObjects().add(tempWall);

        com.badlogic.gdx.maps.objects.RectangleMapObject shelfDef = new com.badlogic.gdx.maps.objects.RectangleMapObject(20,20,10,10);
        shelfDef.setName("shelfDef");
        collisionLayer.getObjects().add(shelfDef);
        
        
        testMap.getLayers().add(collisionLayer);


        //add to the rendring system map
        Field mapField = io.github.eng1group9.systems.RenderingSystem.class.getDeclaredField("map");
        mapField.setAccessible(true);
        mapField.set(null, testMap);

        //add to collision system.map
        Field collisionMapField = io.github.eng1group9.systems.CollisionSystem.class.getDeclaredField("map");
        collisionMapField.setAccessible(true);
        collisionMapField.set(Main.collisionSystem, testMap);


        /*
        init. collision system with RectangleMapObject instances taken from the map objects, tempwall and shelfdef
        it romoves the object from the map by finding an alike rectangle so possibly multiple of needed
        thus adding rectangles from map objects means removeCollisionByName can remove them
        */
        Field wcField = io.github.eng1group9.systems.CollisionSystem.class.getDeclaredField("worldCollision");
        wcField.setAccessible(true);
        java.util.List<com.badlogic.gdx.math.Rectangle> list = new java.util.ArrayList<>();
        
        //use exact instances returned by RectangleMapObject.getRectangle()
        list.add(tempWall.getRectangle());
        list.add(shelfDef.getRectangle());
        wcField.set(Main.collisionSystem, list);
    }

    @After
    public void tearDown() {

        //set flags to init. state
        Main.hasBook = false;
        Main.placed = false;
    }

    /**
     * try to place the book when player dosnt have it
     */
    @Test
    public void placeBook_withoutBook_doesNotPlace() {

        //set flags, player does NOT have a book, hence can NOT have placed it
        Main.hasBook = false;
        Main.placed = false;

        Main.placeBook();

        assertFalse("Book should not be placed when not owned", Main.placed);
    }

    /**
     * pickup the book and then place it, the player does have th book in this test
     */
    @Test
    public void pickup_PlaceBook() {

        //running from same as the previous test flags are reset
        Main.hasBook = false;
        Main.placed = false;

        //pickup the book so we now have it, thus can place it
        Main.pickupBook();
        assertTrue("After pickup, hasBook should be true", Main.hasBook);

        Main.placeBook();
        assertTrue("After placing, placed should be true", Main.placed);
    }
}
