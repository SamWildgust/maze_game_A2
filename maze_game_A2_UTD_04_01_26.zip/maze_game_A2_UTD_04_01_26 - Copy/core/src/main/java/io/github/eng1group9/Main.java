package io.github.eng1group9;

import java.util.List;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import io.github.eng1group9.entities.*;
import io.github.eng1group9.systems.*;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Main extends ApplicationAdapter {

    boolean isFullscreen = false;
    static int gameState = 0;
    /// 0 = Not started
    /// 1 = Playing
    /// 2 = Paused
    /// 3 = Win
    /// 4 = Lose


    //Textbox related
    public static TextInputSystem textbox;
    public static Viewport view;
    public static SpriteBatch batch;
    public static boolean showTextBox = false;
    public static boolean cleared = false;


    public static boolean hasBook = false; //If the player has picked up the book
    public static boolean placed = false; //If the player has placed the book on the bookshelf in the start room

    public static boolean chestDoorOpen = false; // Wether the door to the chest room has been opened.
    public static boolean exitOpen = false; // Wether the exit is open/
    public static boolean spikesLowered = false; // Wether the spikes in the chest room have been lowered.
    public static boolean scrollUsed = false; // Wether the scroll power up has been collected.
    public static boolean bobFound = false; //Status of Bob secret event
    public static int bobBonus = 0; //The bonus added if Bob event is completed
    public static boolean piInteracted = false; //Status of Pi step in Bob event

    public static boolean bookRead = false; //If the player has interacted with the hint book.
    public static boolean spikesTouched = false; // Whether the player collides with the spikes or not.

    static Rectangle spikesHitbox; // Holds the hitbox for the spikes

    public static int longboiBonus = 0; // the bonus to add based on wether LongBoi was found.
    public static int hiddenEventCounter = 0;
    public static int negativeEventCounter = 0;
    public static int positiveEventCounter = 0;

    private static TimerSystem timerSystem = new TimerSystem();
    public boolean showCollision = false;

    private List<Rectangle> worldCollision;
    final static int LONGBOIBONUSAMOUNT = 200;
    final static String TMXPATH = "World/testMap.tmx";

    public static Player player;
    private static boolean playerCaught = false; // Wether the player is currently being held by the Dean.
    final float INITALPLAYERCAUGHTTIME = 1.2f;
    final static float SPIKETOUCH = 0.5f;
    private float playerCaughtTime = INITALPLAYERCAUGHTTIME; // how many seconds the Dean will hold the player when caught.
    static final Vector2 PLAYERSTARTPOS = new Vector2(16, 532); // Where the player begins the game, and returns to when caught.
    final float DEFAULTPLAYERSPEED = 100; // The players speed. 

    private static Dean dean;
    final Vector2 DEANSTARTPOS = new Vector2(32, 352); // Where the Dean begins the game, and returns to after catching the player.
    final float DEFAULTDEANSPEED = 100;
    final int DEANPUNISHMENT = 30; // The number of seconds the Dean adds to the timer.
    final Character[] DEANPATH = { // The path the dean will take (D = Down, U = Up, L = Left, R = Right). The path will loop. 
            'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R', 'R',
            'D', 'D', 'D', 'D', 'D', 'D', 'D', 'D',
            'R', 'R', 'R',
            'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U',
            'L', 'L', 'L',
            'D', 'D', 'D', 'D',
            'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L', 'L'
    };

    final static Color BAD = new Color(1, 1, 0, 1);
    final static Color GOOD = new Color(0, 1, 1, 1);

    public static Main instance;
    public static RenderingSystem renderingSystem = new RenderingSystem();
    public static CollisionSystem collisionSystem = new CollisionSystem();
    public static InputSystem inputSystem = new InputSystem();

    @Override
    public void create() {
        AudioSystem.generate();
        AudioSystem.backgroundMusic();
        renderingSystem.initWorld(TMXPATH, 480, 320);
        collisionSystem.init(renderingSystem.getMapRenderer().getMap());

        TriggerSystem.init(TMXPATH);
        worldCollision = collisionSystem.getWorldCollision();
        player = new Player(PLAYERSTARTPOS, DEFAULTPLAYERSPEED);
        dean = new Dean(DEANSTARTPOS, DEFAULTDEANSPEED, DEANPATH);
        togglePause();
        instance = this;

        batch = new SpriteBatch();
        view = new ScreenViewport();
        textbox = new TextInputSystem(view);
        Gdx.input.setInputProcessor(textbox.st);

        // Get the hitbox from the Collisions system and then change to match collision better
        Rectangle spikesRect = CollisionSystem.chestRoomSpikesRect;
        spikesHitbox = new Rectangle(spikesRect.x, spikesRect.y, 50, spikesRect.height);


    }

    @Override
    public void render() {
        inputSystem.handle(player);
        if (gameState == 1 & showTextBox == false) {
            logic();
        }

        draw();

        if (showTextBox == true) {
            if (!cleared) {
                cleared = true;
                textbox.clear();
            }
            textbox.renderTB(Gdx.graphics.getDeltaTime());
            player.frozen = true;
            if (Gdx.input.isKeyJustPressed(Input.Keys.TAB)) {
                showTextBox = false;
                cleared = false;
                player.frozen = false;
                piInteracted = false;

            }

        }

        if (textbox.getText().equals("telnet 192.168.85.1")) {
            showTextBox = false;
            player.frozen = false;
            RenderingSystem.showLayer("BobLayer");
        }

        spikesInteract(); // Constantly checks if the player has interacted with the spikes or not

        float deltaTime = Gdx.graphics.getDeltaTime(); // time since last frame
        // update Dean (handles stun/movement)
        Dean.update(deltaTime);
    }

    /**
     * Check if the player has the red potion.
     * If they do, show Long Boi and complete the hidden event.
     * If not, tell the player they must find the potion.
     */
    public static void checkForLongboi() {
        Color messageColour = new Color(0.2f, 1, 0.2f, 1);
        if (longboiBonus == 0 && !player.hasRedPotion()) {
            ToastSystem.addToast("Hello There! I seem to have misplaced my Red Potion, could you get it for me?", messageColour);
        } else if (longboiBonus == 0 && player.hasRedPotion()) {
            AudioSystem.hiddenEvent();
            longboiBonus = LONGBOIBONUSAMOUNT;
            ToastSystem.addToast("You found my potion! Thank you!", messageColour);
            RenderingSystem.showLayer("LONGBOI");
            hiddenEventCounter++;
        }
    }

    public void draw() {
        renderingSystem.draw(player, dean, showCollision, timerSystem.elapsedTime, worldCollision);
        switch (gameState) {
            case 0:
                renderingSystem.renderStartOverlay(960, 640);
                break;
            case 2:
                renderingSystem.renderPauseOverlay(960, 640, positiveEventCounter, negativeEventCounter, hiddenEventCounter);
                break;
            case 3:
                renderingSystem.renderWinOverlay(960, 640, timerSystem.getTimeLeft(), calculateScore(), positiveEventCounter, negativeEventCounter, hiddenEventCounter);
                break;
            case 4:
                renderingSystem.renderLoseOverlay(960, 640, positiveEventCounter, negativeEventCounter, hiddenEventCounter);
                break;
            default:
                break;
        }
    }

    /**
     * Open the door of the room with the chest.
     * Remove its hitbox and graphic.
     */
    public static void openChestRoomDoor() {
        if (player.hasChestRoomKey() && !chestDoorOpen) {
            AudioSystem.posEvent();
            ToastSystem.addToast("You Opened the Door!", GOOD);
            collisionSystem.removeCollisionByName("chestRoomDoor");
            RenderingSystem.hideLayer("ChestDoorClosed");
            chestDoorOpen = true;
        }
    }

    /**
     * Open the exit.
     * Remove its hitbox and hide its graphic.
     */
    public static void openExit() {
        if (player.hasExitKey() && !exitOpen) {
            ToastSystem.addToast("You Opened the Exit!", GOOD);
            collisionSystem.removeCollisionByName("exitDoor");
            RenderingSystem.hideLayer("ExitClosed");
            exitOpen = true;
        }
    }

    /**
     * Give the scroll powerup to the player, making the player invisible for 15s.
     * Hide the scroll graphic.
     */
    public static void getScroll() {
        if (!scrollUsed) {
            AudioSystem.posEvent();
            player.becomeInvisible();
            RenderingSystem.hideLayer("Scroll");
            scrollUsed = true;
            ToastSystem.addToast("You got the Scroll!", GOOD);
            ToastSystem.addToast("You are invisible for 15s", GOOD);
            positiveEventCounter++;
        }
    }

    /**
     * Gives dialogue to the player when they interact with Bob, (Binary Message), gives the player 30 more seconds
     */
    public static void secretBob() {
        if (!bobFound && piInteracted) {
            AudioSystem.hiddenEvent();
            timerSystem.moreTime(30);
            RenderingSystem.hideLayer("BobLayer");
            bobFound = true;
            ToastSystem.addToast("You found Bob", GOOD);
            ToastSystem.addToast("1010100 1101000 1100101 1111001\n 1110011 1100001 1111001\n 1000010 1101111 1100010\n 1101001 1110011\n 1001101 1101001 1101011 1100101 100111 1110011\n 1100010 1100101 1110011 1110100\n 1100110 1110010 1101001 1100101 1101110 1100100"
                    , GOOD);
            hiddenEventCounter++;
            positiveEventCounter++;
            bobBonus = 200;
        }
    }

    /**
     * Indicates to the user that they have interacted with the Pi unit.
     * -> Allows them then to interact with Bob.
     */
    public static void piInteract() {
        if (!piInteracted) {
            ToastSystem.addToast("telnet into pi-1 like the lab script says");
            piInteracted = true;
            showTextBox = true;
        }
    }

    /**
     * Event code for the player picking up the  book used to move the bookself to progress through the game.
     */
    public static void pickupBook() {
        if (!hasBook) {
            AudioSystem.bookGrabbed();
            ToastSystem.addToast("Logic in Computer Science: Modelling and Reasoning About Systems");
            RenderingSystem.hideLayer("Book");
            hasBook = true;
        }
    }

    /**
     * Event code for when the player places the book that they picked up from the table
     * Occurs when the player interacts with the bookshelf in the start room, while they have the
     * book needed.
     */
    public static void placeBook() {
        if (hasBook && !placed) {
            AudioSystem.moveShelf();
            ToastSystem.addToast("Theory 3 knowledge acquired");
            placed = true;
            collisionSystem.removeCollisionByName("tempWall");
            RenderingSystem.hideLayer("BookShelf");
            RenderingSystem.showLayer("BookShelfMoved");
            collisionSystem.removeCollisionByName("shelfDef");
        } else if (!hasBook & !placed) {
            ToastSystem.addToast("There's a book missing");
        }
    }


    /**
     * Teleports the player to the lever room when they use the ladder in the start room
     */
    public static void ladderTo() {
        player.ladderTeleport(880, 90);
    }

    /**
     * Teleports the player back to the start room when they use the ladder in the lever room
     */
    public static void ladderFrom() {
        player.ladderTeleport(170, 500);
    }

    /**
     * If the player has collided with the spikes when they are up, they are injured,
     * teleported to the start of the game and lose 30 seconds of time.
     */
    public static void spikesInteract() {
        Rectangle playerRect = player.getHitbox();
        playerRect.setPosition(player.getX(), player.getY() + 20);
        if (playerRect.overlaps(spikesHitbox)) {
            if (!spikesTouched && !spikesLowered) {
                timerSystem.addGradually(30-SPIKETOUCH);
                ToastSystem.addToast("Injured from Spikes :(", BAD);
                player.setPosition(PLAYERSTARTPOS);
                spikesTouched = true;
            }
        } else {
            spikesTouched = false;
        }

    }



    /**
     * Set the game to the started state, and unpause it.
     * Used once to start the game.
     */
    public static void startGame() {
        if (gameState == 0) {
            gameState = 2;
            togglePause();
        }
    }

    /**
     * Set the game to the win state, used when the player escapes. 
     */
    public static void winGame() {
        togglePause();
        gameState = 3;
    }

    /**
     * Set the game to the lose state, used when the player runs out of time. 
     */
    public static void LoseGame() {
        togglePause();
        gameState = 4;
    }

    /**
     * Calculate the players score based on how much time was left and wether they found Long Boi. 
     * @return The score.
     */
    public static int calculateScore() {
        int timeTaken = (int) timerSystem.elapsedTime;
        return 300 - timeTaken + positiveEventCounter * 10 - negativeEventCounter + longboiBonus + bobBonus;
    }

    /**
     * Toggle wether the window should be in Windowed or Fullcreen mode. 
     */
    public void toggleFullscreen() {
        if (isFullscreen) {
                Gdx.graphics.setWindowedMode(960, 640);
            }
            else {
                Gdx.graphics.setFullscreenMode(Gdx.graphics.getDisplayMode());
            }
            isFullscreen = !isFullscreen;
    }

    /**
     * Toggle wether the game shoudl be paused. 
     * This will freeze the player/dean, stop all game logic and display the pause overlay. 
     */
    public static void togglePause() {
        if (gameState == 2) {
            if (!playerCaught) {
                player.unfreeze();
                dean.unfreeze();
            }
            gameState = 1;
        }
        else {
            player.freeze();
            dean.freeze();
            if (gameState == 1) gameState = 2;
        }
    }

    /**
     * Where the game process its logic each frame. 
     * It will not run if the game is paused. 
     */
    public void logic() {
        timerSystem.tick();
        dean.nextMove();
        checkDeanCatch();
        TriggerSystem.checkTouchTriggers(player);
        player.update();
    }

    /**
     * Checks if the dean has caught the player, and punishes them if he has by removing 50s from time left. 
     */
    public void checkDeanCatch() {
        if (dean.canReach(player) && !playerCaught) {
            startPlayerCatch();
        }
        else if (playerCaught) {
            if (playerCaughtTime <= 0) {
                endPlayerCatch();
                playerCaughtTime = INITALPLAYERCAUGHTTIME;
            }
            else {
                float delta = Gdx.graphics.getDeltaTime();
                playerCaughtTime -= delta;
            }
        }
    }

    /**
     * Run when the player is first caught by the game. 
     * This will begin the sequence where the player is held in detention while the timer goes down.
     * This will freeze the player and dean. 
     */
    private void startPlayerCatch() {
        AudioSystem.deanCatch();
        playerCaught = true;
        player.freeze();
        player.setPosition(PLAYERSTARTPOS);
        dean.freeze();
        dean.changeAnimation(3);
        dean.setPosition(PLAYERSTARTPOS.x + 32, PLAYERSTARTPOS.y);
        timerSystem.addGradually(DEANPUNISHMENT - INITALPLAYERCAUGHTTIME); // 48 not 50 because you spend 2s stood while the timer goes down.
        ToastSystem.addToast("You were caught by the Dean!", BAD);
        ToastSystem.addToast("You were stuck being lectured for 50s!", BAD);
        negativeEventCounter++;
    }

    /**
     * This will end the sequence where the player is held in detention while the timer goes down.
     * This will unfreeze the player and dean.
     * It will rest the dean to the start of its patrol. 
     */
    private void endPlayerCatch() {
        dean.setPosition(DEANSTARTPOS);
        dean.restartPath();
        dean.unfreeze();
        player.unfreeze();
        playerCaught = false;
    }

    /**
     * Use to drop remove the spikes in the chest room when the switch is pressed. 
     */
    public static void dropSpikes() {
        if (!spikesLowered) {
            AudioSystem.leverPulled();
            collisionSystem.removeCollisionByName("chestRoomSpikes");
            ToastSystem.addToast("You Lowered the Spikes!", GOOD);
            RenderingSystem.hideLayer("Spikes");
            RenderingSystem.showLayer("Switch");
            spikesLowered = true;
        }
    }


    /**
     * Used to have the player get a hint (for the longboi bonus).
     * It can only tell you information if you haven't already interacted with longboi
     */
    public static void Hint() {
        if (longboiBonus == 0 && !bookRead) {
            AudioSystem.hiddenEvent();
            ToastSystem.addToast("There's been strange quacking behind that wall for days...", GOOD);
            bookRead = true;
        }
    }

    @Override
    public void resize(int width, int height) {
        renderingSystem.resize(width, height);
    }

    @Override
    public void pause() {
        togglePause();
    }

    @Override
    public void resume() {
        togglePause();
    }
}
