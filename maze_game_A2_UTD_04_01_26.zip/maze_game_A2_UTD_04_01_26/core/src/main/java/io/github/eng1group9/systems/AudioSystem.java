package io.github.eng1group9.systems;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;

public class AudioSystem {

    // Stores all the variables for sounds that are played
    public static Sound leverPulled;
    public static Sound hiddenEvent;
    public static Sound posEvent;
    public static Sound potion;
    public static Sound deanCatch;
    public static Sound shelfMove;
    public static Sound bookGrabbed;
    public static Sound chestOpen;

    public static Music music; // Background


    /**
     * Stores all the sound/music files in the previously instantiated variables
     */
    public static void generate() {

        leverPulled = Gdx.audio.newSound(Gdx.files.internal("Music/leverpulled.wav"));
        hiddenEvent =  Gdx.audio.newSound(Gdx.files.internal("Music/hiddenevent.wav"));
        posEvent = Gdx.audio.newSound(Gdx.files.internal("Music/posevent.wav"));
        potion = Gdx.audio.newSound(Gdx.files.internal("Music/potion.mp3"));
        deanCatch = Gdx.audio.newSound(Gdx.files.internal("Music/deanCatch.mp3"));
        shelfMove = Gdx.audio.newSound(Gdx.files.internal("Music/movingShelf.mp3"));
        bookGrabbed = Gdx.audio.newSound(Gdx.files.internal("Music/pageTurning.mp3"));
        chestOpen = Gdx.audio.newSound(Gdx.files.internal("Music/chestopen.mp3"));

        music = Gdx.audio.newMusic(Gdx.files.internal("Music/BackgroundMusic.mp3"));
        music.setLooping(true); // The music will go from the beginning
        music.setVolume(0.5f);

    }

    /**
     * When the lever is pulled, the audio will play
     */
    public static void leverPulled() { leverPulled.play(1.0f); }

    /**
     * When a hidden event happens, the audio will play
     */
    public static void hiddenEvent() {hiddenEvent.play(1.0f); }

    /**
     * When a positive event happens, the audio will play
     */
    public static void posEvent() {posEvent.play(1.0f);}

    /**
     * When the player picks up the potion, the audio will play
     */
    public static void potion() {potion.play(1.0f);}

    /**
     * When the player is caught by the dean, the audio will play
     */
    public static void deanCatch() {deanCatch.play(1.0f);}

    /**
     * When the player moves the bookshelf, the audio will play
     */
    public static void moveShelf() {shelfMove.play(1.0f);}

    /**
     * When the player picks up the THE3 book, the audio will play
     */
    public static void bookGrabbed() {bookGrabbed.play(1.0f);}

    /**
     * When the chest has been opened, this sound effect will play
     */
    public static void chestOpen() {chestOpen.play(1.0f);}

    /**
     * Ensures music will always play
     */
    public static void backgroundMusic() {
        if(!music.isPlaying())  {
            music.play(); }
    }


    public static void dispose() {
        leverPulled.dispose();
        hiddenEvent.dispose();
        posEvent.dispose();
        potion.dispose();
        deanCatch.dispose();
        shelfMove.dispose();
        bookGrabbed.dispose();
        music.dispose();
    }
}
